import React from "react";
import Rotas from './paginas/Rotas/index';

function App(){
  return(
    <div>
      <Rotas/>
    </div>
  )
}
export default App;